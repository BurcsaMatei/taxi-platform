# components/sections/homepage/ShortTextHomepage.tsx

**Ce face:** Componentă React + stilurile aferente (Vanilla Extract), combinate.

### components/sections/homepage/ShortTextHomepage.tsx

```tsx
import { shortTextClass } from '../../../styles/shortText.css';

const ShortTextHomepage = () => (
  <h3 className={shortTextClass}>
    Aici vine partea de text h3 si poate fi modificat in functie de nevoile clientului.
  </h3>
);

export default ShortTextHomepage;

```
_Nu a fost găsit un stylesheet pereche în styles/._
