# components/Card.tsx

**Ce face:** Componentă React + stilurile aferente (Vanilla Extract), combinate.

### components/Card.tsx

```tsx
// components/Card.tsx
import React from "react";
import Img from "./ui/Img";
import { cardClass, cardCaptionClass } from "../styles/card.css";
import { imageWrap } from "../styles/cardImageWrap.css";

type CardProps = {
  src?: string;
  alt?: string;
  caption?: React.ReactNode;
  captionClassName?: string;
  priority?: boolean;
  sizes?: string;
  quality?: number;
};

const Card = ({
  src = "/images/card.jpg",
  alt = "Imagine card",
  caption = "Comentariu sau titlu aici",
  captionClassName,
  priority = false,
  sizes,
  quality = 75,
}: CardProps) => (
  <div className={cardClass}>
    {/* Imaginea full-bleed */}
    <div className={imageWrap}>
      <Img
        src={src}
        alt={alt}
        fill
        sizes={sizes ?? "(max-width: 600px) 100vw, (max-width: 1200px) 50vw, 25vw"}
        style={{ objectFit: "cover" }}
        priority={priority}
        
        quality={quality}
      />
    </div>

    {/* Caption cu padding separat */}
    <div className={[cardCaptionClass, captionClassName].filter(Boolean).join(" ")}>
  {caption}
</div>

  </div>
);

export default Card;

```
### styles/Card.css.ts

```ts
// styles/card.css.ts
import { style } from '@vanilla-extract/css';
import { vars } from './tokens.css';

// Card wrapper
export const card = style({
  background: vars.color.background,
  borderRadius: vars.radius.base,
  boxShadow: '0 8px 28px rgba(50,60,90,0.13)',
  overflow: 'hidden',
  display: 'flex',
  flexDirection: 'column',
  alignItems: 'stretch', // 🔹 întinde imaginea pe toată lățimea
  transition: 'transform 0.18s cubic-bezier(.5,1.5,.5,1), box-shadow .18s ease',
  selectors: {
    '&:hover': {
      transform: 'scale(1.035)',
      boxShadow: '0 16px 40px rgba(50,60,90,0.18)',
    },
  },
  maxWidth: 440,
  margin: '0 auto',
});

// Alias pentru compatibilitate
export const cardClass = card;

// Caption / conținut
export const cardCaptionClass = style({
  width: '100%',
  padding: vars.spacing.lg, // 🔹 padding doar pe caption
  color: vars.color.text,
  textAlign: 'center',
  fontWeight: 500,
  fontFamily: vars.font.base,
});

```
