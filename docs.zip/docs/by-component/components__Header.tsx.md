# components/Header.tsx

**Ce face:** Componentă React + stilurile aferente (Vanilla Extract), combinate.

### components/Header.tsx

```tsx
// components/Header.tsx
'use client';

import { useState } from "react";
import Link from "next/link";
import {
  headerClass,
  headerInnerClass,
  logoBoxClass,
  desktopNavClass,
  desktopNavLinkClass,
  burgerButtonClass,
  mobileNavClass,
  mobileListClass,
  mobileListItemClass,
  mobileNavLinkClass,
} from "../styles/header.css";

// import relativ, conform structurii tale
import LogoMark from "../src/assets/logo.svg";

export default function Header() {
  const [isOpen, setIsOpen] = useState(false);

  return (
    <header className={headerClass} role="banner">
      <div className={headerInnerClass}>
        {/* Logo */}
        <div className={logoBoxClass}>
          <Link
            href="/"
            aria-label="KonceptID — Acasă"
            style={{ lineHeight: 0, display: "inline-flex", height: "100%", alignItems: "center" }}
          >
            <LogoMark style={{ display: "block", height: "100%", width: "auto" }} />
          </Link>
        </div>

        {/* Desktop nav */}
        <nav className={desktopNavClass} aria-label="Navigație principală">
          <Link href="/" className={desktopNavLinkClass}>Home</Link>
          <Link href="/services" className={desktopNavLinkClass}>Servicii</Link>
          <Link href="/galerie" className={desktopNavLinkClass}>Galerie</Link>
          <Link href="/contact" className={desktopNavLinkClass}>Contact</Link>
        </nav>

        {/* Burger (doar pe mobil) */}
        <button
          type="button"
          className={burgerButtonClass}
          aria-label={isOpen ? "Închide meniul" : "Deschide meniul"}
          aria-expanded={isOpen}
          aria-controls="site-mobile-nav"
          onClick={() => setIsOpen(v => !v)}
        >
          {isOpen ? "✕" : "☰"}
        </button>
      </div>

      {/* Mobile nav — listă verticală simplă, fără overlay */}
      {isOpen && (
        <nav id="site-mobile-nav" className={mobileNavClass} aria-label="Navigație mobil">
          <ul className={mobileListClass}>
            <li className={mobileListItemClass}>
              <Link href="/" className={mobileNavLinkClass} onClick={() => setIsOpen(false)}>Home</Link>
            </li>
            <li className={mobileListItemClass}>
              <Link href="/services" className={mobileNavLinkClass} onClick={() => setIsOpen(false)}>Servicii</Link>
            </li>
            <li className={mobileListItemClass}>
              <Link href="/galerie" className={mobileNavLinkClass} onClick={() => setIsOpen(false)}>Galerie</Link>
            </li>
            <li className={mobileListItemClass}>
              <Link href="/contact" className={mobileNavLinkClass} onClick={() => setIsOpen(false)}>Contact</Link>
            </li>
          </ul>
        </nav>
      )}
    </header>
  );
}

```
### styles/Header.css.ts

```ts
// styles/header.css.ts
import { style, createVar, globalStyle } from "@vanilla-extract/css";
import { vars } from "./tokens.css";

/* Vars: înălțimea header-ului (dacă ai nevoie ulterior) */
export const headerHeightVar = createVar();

/* Header wrapper */
export const headerClass = style({
  position: "sticky",
  top: 0,
  width: "100%",
  zIndex: 3000,
  background: vars.color.headerBg,
  borderBottom: `1px solid #e5e7eb`,
  boxShadow: "0 6px 28px -8px rgba(50,60,90,0.16)",
});

/* Container intern */
export const headerInnerClass = style({
  maxWidth: 1200,
  margin: "0 auto",
  width: "100%",
  display: "flex",
  alignItems: "center",
  justifyContent: "space-between",
  padding: `${vars.spacing.md} ${vars.spacing.lg}`,
  minHeight: headerHeightVar,
});

/* Logo */
export const logoBoxClass = style({
  height: "56px",
  display: "flex",
  alignItems: "center",
  maxWidth: "240px",
});
globalStyle(`${logoBoxClass} svg`, { display: "block", height: "100%", width: "auto" });

/* Desktop nav */
export const desktopNavClass = style({
  display: "none",
  "@media": { "screen and (min-width: 901px)": { display: "flex", gap: "24px", alignItems: "center" } },
});

export const desktopNavLinkClass = style({
  color: vars.color.text,
  textDecoration: "none",
  fontWeight: 500,
  fontSize: "1.05rem",
  transition: "color 0.2s",
  ":hover": { color: vars.color.primary },
});

/* Burger button (mobil) */
export const burgerButtonClass = style({
  background: "transparent",
  border: "none",
  cursor: "pointer",
  fontSize: "2rem",
  "@media": { "screen and (min-width: 901px)": { display: "none" } },
});

/* Mobile nav container (sub header), simplu */
export const mobileNavClass = style({
  display: "block",
  background: vars.color.headerBg,
  borderTop: "1px solid #e5e7eb",
  "@media": { "screen and (min-width: 901px)": { display: "none" } },
});

/* UL vertical, fără bullets — coloană garantat */
export const mobileListClass = style({
  listStyle: "none",
  margin: 0,
  padding: `12px ${vars.spacing.lg} 16px`,
  display: "flex",
  flexDirection: "column",
  rowGap: "8px",
});

/* LI bloc */
export const mobileListItemClass = style({
  display: "block",
});

/* Link mobil — block 100%, ocupă rândul */
export const mobileNavLinkClass = style({
  display: "block",
  width: "100%",
  padding: "12px 0",
  color: vars.color.text,
  textDecoration: "none",
  fontWeight: 500,
  fontSize: "1.05rem",
  lineHeight: 1.25,
  transition: "color 0.2s",
  ":hover": { color: vars.color.primary },
});

```
