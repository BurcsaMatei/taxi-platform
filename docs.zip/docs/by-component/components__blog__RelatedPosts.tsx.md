# components/blog/RelatedPosts.tsx

**Ce face:** Componentă React + stilurile aferente (Vanilla Extract), combinate.

### components/blog/RelatedPosts.tsx

```tsx
// components/blog/RelatedPosts.tsx
import Link from "next/link";
import {
  relatedWrapClass,
  relatedTitleClass,
  relatedListClass,
  relatedLinkClass,
} from "../../styles/relatedPosts.css"

type Item = { slug: string; title: string };

export default function RelatedPosts({ items }: { items: Item[] }) {
  if (!items || items.length === 0) return null;
  return (
    <section className={relatedWrapClass} aria-labelledby="related-posts-title">
      <h3 id="related-posts-title" className={relatedTitleClass}>
        Poate te mai interesează și:
      </h3>
      <ul className={relatedListClass}>
        {items.map((p) => (
          <li key={p.slug}>
            <Link href={`/blog/${p.slug}`} className={relatedLinkClass}>
              {p.title}
            </Link>
          </li>
        ))}
      </ul>
    </section>
  );
}

```
### styles/RelatedPosts.css.ts

```ts
// styles/relatedPosts.css.ts
import { style } from "@vanilla-extract/css";

export const relatedWrapClass = style({
  maxWidth: 820,
  margin: "32px auto 64px",
});

export const relatedTitleClass = style({
  fontSize: 20,
  lineHeight: 1.2,
  marginBottom: 12,
});

export const relatedListClass = style({
  listStyle: "none",
  padding: 0,
  margin: 0,
  display: "grid",
  rowGap: 10,
});

export const relatedLinkClass = style({
  color: "#0ea5e9",
  textDecoration: "underline",
  selectors: {
    "&:hover": { textDecoration: "none" },
  },
});

```
