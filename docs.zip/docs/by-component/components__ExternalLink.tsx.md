# components/ExternalLink.tsx

**Ce face:** Componentă React + stilurile aferente (Vanilla Extract), combinate.

### components/ExternalLink.tsx

```tsx
// components/ExternalLink.tsx
import { AnchorHTMLAttributes } from "react";

type ExternalLinkProps = AnchorHTMLAttributes<HTMLAnchorElement> & {
  href: string;
};

export default function ExternalLink({ href, children, className, ...rest }: ExternalLinkProps) {
  return (
    <a
      href={href}
      target="_blank"
      rel="noopener noreferrer"
      className={className}   // ✅ propagăm clasa primită
      {...rest}
    >
      {children}
    </a>
  );
}

```
_Nu a fost găsit un stylesheet pereche în styles/._
