# components/Breadcrumbs.tsx

**Ce face:** Componentă React + stilurile aferente (Vanilla Extract), combinate.

### components/Breadcrumbs.tsx

```tsx
// components/Breadcrumbs.tsx
import {
  breadcrumbsWrapperClass,
  breadcrumbsListClass,
  breadcrumbLinkClass,
  breadcrumbCurrentClass,
  breadcrumbItemClass,
} from "../styles/breadcrumbs.css";

type Crumb = { name: string; href?: string; current?: boolean };

export default function Breadcrumbs({ items }: { items: Crumb[] }) {
  return (
    <nav aria-label="breadcrumb" className={breadcrumbsWrapperClass}>
      <ol className={breadcrumbsListClass}>
        {items.map((c, i) => (
          <li
            key={i}
            className={breadcrumbItemClass}
            aria-current={c.current ? "page" : undefined}
          >
            {c.href && !c.current ? (
              <a href={c.href} className={breadcrumbLinkClass}>
                {c.name}
              </a>
            ) : (
              <span className={breadcrumbCurrentClass}>{c.name}</span>
            )}
          </li>
        ))}
      </ol>
    </nav>
  );
}

```
### styles/Breadcrumbs.css.ts

```ts
// styles/breadcrumbs.css.ts
import { style } from "@vanilla-extract/css";

export const breadcrumbsWrapperClass = style({
  margin: "1rem 0",
  display: "flex",          // 🔹 adăugat
  justifyContent: "center", // 🔹 adăugat
});

export const breadcrumbsListClass = style({
  display: "flex",
  alignItems: "center",
  listStyle: "none",
  padding: 0,
  margin: 0,
});

export const breadcrumbLinkClass = style({
  color: "#1d4ed8", // albastru link
  textDecoration: "none",
  ":hover": {
    textDecoration: "underline",
  },
});

export const breadcrumbCurrentClass = style({
  color: "#6b7280", // gri pentru ultima treaptă
});

/* 🔹 Separatorul "/" automat */
export const breadcrumbItemClass = style({
  selectors: {
    "&:not(:first-child)::before": {
      content: "'/'",
      margin: "0 0.5rem",
      color: "#b5b5b5",
    },
  },
});

```
