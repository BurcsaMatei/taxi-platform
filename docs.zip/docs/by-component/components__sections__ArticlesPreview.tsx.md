# components/sections/ArticlesPreview.tsx

**Ce face:** Componentă React + stilurile aferente (Vanilla Extract), combinate.

### components/sections/ArticlesPreview.tsx

```tsx
// components/sections/ArticlesPreview.tsx
import Link from "next/link";
import Image from "next/image";
import { motion } from "framer-motion";
import { BlogPostLite } from "../../lib/blogData"
import { formatDateISOtoRo } from "../../lib/dates"
import {
  sectionClass,
  headerClass,
  titleClass,
  subtitleClass,
  gridClass,
  cardClass,
  coverClass,
  metaRowClass,
  cardTitleClass,
  excerptClass,
  ctaRowClass,
  emptyClass,
} from "../../styles/articlesPreview.css"
import Button from "../../components/Button"

type Props = {
  posts: BlogPostLite[];
  title?: string;
  subtitle?: string;
  showCta?: boolean;
};

export default function ArticlesPreview({
  posts,
  title = "Articole recente",
  subtitle = "Noutăți și ghiduri scurte.",
  showCta = true,
}: Props) {
  return (
    <section className={sectionClass} aria-labelledby="articles-preview-title">
      <div className={headerClass}>
        <h2 id="articles-preview-title" className={titleClass}>{title}</h2>
        <p className={subtitleClass}>{subtitle}</p>
      </div>

      {(!posts || posts.length === 0) ? (
        <div className={emptyClass}>Nu avem încă articole publice. Revino curând.</div>
      ) : (
        <>
          <div className={gridClass}>
            {posts.map((post) => (
              <motion.article
                key={post.slug}
                className={cardClass}
                initial={{ opacity: 0, y: 16 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, amount: 0.3 }}
                transition={{ duration: 0.3 }}
              >
                <Link href={`/blog/${post.slug}`} aria-label={post.title}>
                  <div className={coverClass}>
                    <Image
                      src={post.coverImage || "/images/blog/placeholder.jpg"}
                      alt={post.title}
                      fill
                      sizes="(max-width: 768px) 100vw, (max-width: 1200px) 50vw, 33vw"
                    />
                  </div>
                  <div className={metaRowClass}>
                    <span>{formatDateISOtoRo(post.date)}</span>
                    {post.readingTime && (
                      <>
                        <span>&middot;</span>
                        <span>{post.readingTime}</span>
                      </>
                    )}
                  </div>
                  <h3 className={cardTitleClass}>{post.title}</h3>
                  <p className={excerptClass}>{post.excerpt}</p>
                </Link>
              </motion.article>
            ))}
          </div>

          {showCta && (
            <div className={ctaRowClass}>
              <Button>
                <Link href="/blog">Vezi toate articolele →</Link>
              </Button>
            </div>
          )}
        </>
      )}
    </section>
  );
}

```
### styles/ArticlesPreview.css.ts

```ts
// styles/articlesPreview.css.ts
import { style } from "@vanilla-extract/css";
import { container } from "./container.css"; // container global

export const sectionClass = style([
  container,
  {
    padding: "40px 16px",
  },
]);

export const headerClass = style({
  textAlign: "center",
  marginBottom: 32,
});

export const titleClass = style({
  fontSize: 28,
  lineHeight: 1.2,
  margin: 0,
});

export const subtitleClass = style({
  color: "#4b5563",
  marginTop: 6,
  fontSize: 16,
});

export const gridClass = style({
  display: "grid",
  gridTemplateColumns: "1fr",
  gap: 20,
  "@media": {
    "screen and (min-width: 768px)": { gridTemplateColumns: "1fr 1fr" },
    "screen and (min-width: 1200px)": { gridTemplateColumns: "1fr 1fr 1fr" },
  },
});

export const cardClass = style({
  borderRadius: 18,
  overflow: "hidden",
  background: "white",
  boxShadow: "0 2px 20px rgba(0,0,0,0.06)",
  selectors: { "&:hover": { transform: "translateY(-2px)", boxShadow: "0 6px 26px rgba(0,0,0,0.10)" } },
  transition: "transform .2s ease, box-shadow .2s ease",
});

export const coverClass = style({
  position: "relative",
  width: "100%",
  height: 200,
  background: "#f3f4f6",
});

export const metaRowClass = style({
  display: "flex",
  gap: 8,
  alignItems: "center",
  color: "#6b7280",
  fontSize: 13,
  padding: "12px 16px 0",
});

export const cardTitleClass = style({
  fontSize: 18,
  lineHeight: 1.2,
  padding: "8px 16px 0",
});

export const excerptClass = style({
  padding: "8px 16px 16px",
  color: "#374151",
  fontSize: 15,
});

export const ctaRowClass = style({
  display: "flex",
  justifyContent: "center",
  marginTop: 32,
});

export const emptyClass = style({
  padding: "20px",
  borderRadius: 12,
  background: "#f9fafb",
  color: "#6b7280",
  textAlign: "center",
});

```
