# components/JsonLd.tsx

**Ce face:** Componentă React + stilurile aferente (Vanilla Extract), combinate.

### components/JsonLd.tsx

```tsx
// components/JsonLd.tsx
import React from "react";

export default function JsonLd({ schema }: { schema: unknown }) {
  return (
    <script
      type="application/ld+json"
      // eslint-disable-next-line react/no-danger
      dangerouslySetInnerHTML={{ __html: JSON.stringify(schema) }}
    />
  );
}

```
_Nu a fost găsit un stylesheet pereche în styles/._
