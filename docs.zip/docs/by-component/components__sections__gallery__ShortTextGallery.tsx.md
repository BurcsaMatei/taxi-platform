# components/sections/gallery/ShortTextGallery.tsx

**Ce face:** Componentă React + stilurile aferente (Vanilla Extract), combinate.

### components/sections/gallery/ShortTextGallery.tsx

```tsx
import { shortTextClass } from '../../../styles/shortText.css';

const ShortTextGallery = () => (
  <h3 className={shortTextClass}>
    Aici vine partea de text h3 si poate fi modificat in functie de nevoile clientului.
  
  </h3>
);

export default ShortTextGallery;

```
_Nu a fost găsit un stylesheet pereche în styles/._
