# components/List.tsx

**Ce face:** Componentă React + stilurile aferente (Vanilla Extract), combinate.

### components/List.tsx

```tsx
import * as React from "react";
import ListItem from "./ListItem";
import { User } from "../interfaces";

type Props = {
  items: User[];
};

const List = ({ items }: Props) => (
  <ul>
    {items.map((item) => (
      <li key={item.id}>
        <ListItem data={item} />
      </li>
    ))}
  </ul>
);

export default List;

```
_Nu a fost găsit un stylesheet pereche în styles/._
