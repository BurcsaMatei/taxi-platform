# components/Footer.tsx

**Ce face:** Componentă React + stilurile aferente (Vanilla Extract), combinate.

### components/Footer.tsx

```tsx
'use client';

import Link from "next/link";
import {
  footerClass,
  footerLogoBoxClass,
  footerDividerClass,
  footerCopyClass,
} from "../styles/footer.css";
import { useCookieConsent } from "../components/cookies/CookieProvider";

// ✅ logo din src/assets (SVGR)
import LogoMark from "../src/assets/logo.svg";

// ✅ import nou pentru linkuri externe
import ExternalLink from "./ExternalLink";

export default function Footer() {
  const { openSettings } = useCookieConsent();

  return (
    <footer className={footerClass} role="contentinfo">
      {/* Logo centrat deasupra liniei */}
      <div className={footerLogoBoxClass}>
        <Link
          href="/"
          aria-label="KonceptID — Acasă"
          style={{ lineHeight: 0, display: "inline-flex", alignItems: "center" }}
        >
          <LogoMark style={{ display: "block", height: 40, width: "auto" }} />
        </Link>
      </div>

      {/* Separator sub logo */}
      <hr className={footerDividerClass} />

      {/* Text copyright */}
      <span className={footerCopyClass}>
        © {new Date().getFullYear()} KonceptID Base – All rights reserved.
      </span>

      {/* Link-uri */}
      <div style={{ marginTop: 8, fontSize: 14, textAlign: "center" }}>
        <a
          href="#"
          onClick={(e) => {
            e.preventDefault();
            openSettings(); // deschide dialogul de cookies instant
          }}
        >
          Setări cookie
        </a>{" "}
        ·{" "}
        <Link href="/cookie-policy">
          Politica Cookie
        </Link>{" "}
        ·{" "}
        <ExternalLink href="https://anpc.ro/">ANPC</ExternalLink>
      </div>
    </footer>
  );
}

```
### styles/Footer.css.ts

```ts
// styles/footer.css.ts
import { style } from '@vanilla-extract/css';
import { vars } from './tokens.css';

export const footerClass = style({
  background: vars.color.footerBg,
  color: vars.color.text,
  fontFamily: vars.font.base,
  padding: `${vars.spacing.md} ${vars.spacing.lg}`,
  textAlign: 'center',
  fontSize: '1rem',
  borderTop: `1px solid ${vars.color.primary}`,
  marginTop: vars.spacing.lg,
});

export const footerLogoBoxClass = style({
  height: '40px',              // pt. autosize (SVG <-> height:100%)
  minHeight: '40px',           // siguranță pe unele motoare de layout
  lineHeight: 0,               // elimină spațiul „baseline”
  display: 'flex',
  alignItems: 'center',
  justifyContent: 'center',
  paddingTop: '8px',
  paddingBottom: '8px',
});

export const footerDividerClass = style({
  width: '100%',
  maxWidth: 1200,
  margin: '8px auto 12px auto',
  border: 'none',
  borderTop: '1px solid #e4e8ef',
});

export const footerCopyClass = style({
  display: 'block',
  marginTop: '4px',
});

```
