# components/Separator.tsx

**Ce face:** Fișier de cod parte din aplicație.

```tsx
// components/Separator.tsx
import { separatorClass } from '../styles/separator.css';

const Separator = () => (
  <hr className={separatorClass} />
);

export default Separator;

```
