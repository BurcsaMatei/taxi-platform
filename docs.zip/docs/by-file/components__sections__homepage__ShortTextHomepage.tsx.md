# components/sections/homepage/ShortTextHomepage.tsx

**Ce face:** Fișier de cod parte din aplicație.

```tsx
import { shortTextClass } from '../../../styles/shortText.css';

const ShortTextHomepage = () => (
  <h3 className={shortTextClass}>
    Aici vine partea de text h3 si poate fi modificat in functie de nevoile clientului.
  </h3>
);

export default ShortTextHomepage;

```
