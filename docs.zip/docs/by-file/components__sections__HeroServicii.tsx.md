# components/sections/HeroServicii.tsx

**Ce face:** Fișier de cod parte din aplicație.

```tsx
import { motion } from 'framer-motion';
import * as s from "../../styles/services.css";
import AnimatedIcon from "../ui/AnimatedIcon";

export type ServiciuItem = {
  id: string;
  title: string;
  description: string;
  href?: string;
  iconSrc?: string;
};

const DEFAULT_ITEMS: ServiciuItem[] = [
  { id: 'web-design', title: 'Web Design', description: 'Design modern, responsive orientat pe conversii și brand.', iconSrc: '/icons/servicii/service1.svg' },
  { id: 'nextjs-dev', title: 'Dezvoltare Next.js', description: 'Site-uri rapide, accesibile, scalabile, Pages Router.', iconSrc: '/icons/servicii/service2.svg' },
  { id: 'seo', title: 'Optimizare & SEO', description: 'CWV, meta OG, schema, sitemap & bune practici tehnice.', iconSrc: '/icons/servicii/service3.svg' },
  { id: 'content', title: 'Conținut & Blog', description: 'Arhitectură de conținut, articole, structuri SEO-ready.', iconSrc: '/icons/servicii/service4.svg' },
];

type Props = {
  items?: ServiciuItem[];
  eyebrow?: string;
  title?: string;
  subtitle?: string;
};

export function HeroServicii({
  items = DEFAULT_ITEMS,
  eyebrow = 'Servicii',
  title = 'Tot ce ai nevoie pentru un site solid',
  subtitle = 'De la design și Next.js la SEO tehnic și conținut — implementăm pas cu pas, curat și predictibil.',
}: Props) {
  return (
    <section className={s.sectionPad} aria-labelledby="services-title">
      <div className={s.heroHeader}>
        <span className={s.eyebrow}>{eyebrow}</span>
        <h1 id="services-title" className={s.heroTitle}>{title}</h1>
        <p className={s.heroSubtitle}>{subtitle}</p>
      </div>

      <motion.ul
        className={s.grid}
        initial="hidden"
        animate="show"
        variants={{
          hidden: { opacity: 0 },
          show: {
            opacity: 1,
            transition: { staggerChildren: 0.08, delayChildren: 0.05 },
          },
        }}
      >
        {items.map((card) => (
          <motion.li
            key={card.id}
            className={s.card}
            variants={{ hidden: { opacity: 0, y: 12 }, show: { opacity: 1, y: 0 } }}
          >
            <div className={s.cardIconWrap}>
              {card.iconSrc ? (
                <AnimatedIcon
                  src={card.iconSrc}
                  alt=""
                  size={48}
                  hoverTilt={true}
                />
              ) : (
                <div className={s.cardIconPlaceholder} aria-hidden="true" />
              )}
            </div>
            <h2 className={s.cardTitle}>{card.title}</h2>
            <p className={s.cardDesc}>{card.description}</p>
            {card.href ? (
              <a className={s.cardLink} href={card.href} aria-label={card.title}>
                Află mai mult
              </a>
            ) : null}
          </motion.li>
        ))}
      </motion.ul>
    </section>
  );
}

```
