# data/galleryCaptions.json

**Ce face:** Fișier de cod parte din aplicație.

```json
[
  {
    "src": "/images/gallery/g-001.jpg",
    "alt": "",
    "title": "g-001",
    "caption": "",
    "description": ""
  },
  {
    "src": "/images/gallery/g-002.jpg",
    "alt": "",
    "title": "g-002",
    "caption": "",
    "description": ""
  },
  {
    "src": "/images/gallery/g-003.jpg",
    "alt": "",
    "title": "g-003",
    "caption": "",
    "description": ""
  },
  {
    "src": "/images/gallery/g-004.jpg",
    "alt": "",
    "title": "g-004",
    "caption": "",
    "description": ""
  },
  {
    "src": "/images/gallery/g-005.jpg",
    "alt": "",
    "title": "g-005",
    "caption": "",
    "description": ""
  },
  {
    "src": "/images/gallery/g-006.jpg",
    "alt": "",
    "title": "g-006",
    "caption": "",
    "description": ""
  },
  {
    "src": "/images/gallery/g-007.jpg",
    "alt": "",
    "title": "g-007",
    "caption": "",
    "description": ""
  },
  {
    "src": "/images/gallery/g-008.jpg",
    "alt": "",
    "title": "g-008",
    "caption": "",
    "description": ""
  },
  {
    "src": "/images/gallery/g-009.jpg",
    "alt": "",
    "title": "g-009",
    "caption": "",
    "description": ""
  },
  {
    "src": "/images/gallery/g-010.jpg",
    "alt": "",
    "title": "g-010",
    "caption": "",
    "description": ""
  },
  {
    "src": "/images/gallery/g-011.jpg",
    "alt": "",
    "title": "g-011",
    "caption": "",
    "description": ""
  },
  {
    "src": "/images/gallery/g-012.jpg",
    "alt": "",
    "title": "g-012",
    "caption": "",
    "description": ""
  },
  {
    "src": "/images/gallery/g-013.jpg",
    "alt": "",
    "title": "g-013",
    "caption": "",
    "description": ""
  },
  {
    "src": "/images/gallery/g-014.jpg",
    "alt": "",
    "title": "g-014",
    "caption": "",
    "description": ""
  },
  {
    "src": "/images/gallery/g-015.jpg",
    "alt": "",
    "title": "g-015",
    "caption": "",
    "description": ""
  },
  {
    "src": "/images/gallery/g-016.jpg",
    "alt": "",
    "title": "g-016",
    "caption": "",
    "description": ""
  },
  {
    "src": "/images/gallery/g-017.jpg",
    "alt": "",
    "title": "g-017",
    "caption": "",
    "description": ""
  },
  {
    "src": "/images/gallery/g-018.jpg",
    "alt": "",
    "title": "g-018",
    "caption": "",
    "description": ""
  },
  {
    "src": "/images/gallery/g-019.jpg",
    "alt": "",
    "title": "g-019",
    "caption": "",
    "description": ""
  },
  {
    "src": "/images/gallery/g-020.jpg",
    "alt": "",
    "title": "g-020",
    "caption": "",
    "description": ""
  },
  {
    "src": "/images/gallery/g-021.jpg",
    "alt": "",
    "title": "g-021",
    "caption": "",
    "description": ""
  },
  {
    "src": "/images/gallery/g-022.jpg",
    "alt": "",
    "title": "g-022",
    "caption": "",
    "description": ""
  },
  {
    "src": "/images/gallery/g-023.jpg",
    "alt": "",
    "title": "g-023",
    "caption": "",
    "description": ""
  },
  {
    "src": "/images/gallery/g-024.jpg",
    "alt": "",
    "title": "g-024",
    "caption": "",
    "description": ""
  },
  {
    "src": "/images/gallery/g-025.jpg",
    "alt": "",
    "title": "g-025",
    "caption": "",
    "description": ""
  },
  {
    "src": "/images/gallery/g-026.jpg",
    "alt": "",
    "title": "g-026",
    "caption": "",
    "description": ""
  },
  {
    "src": "/images/gallery/g-027.jpg",
    "alt": "",
    "title": "g-027",
    "caption": "",
    "description": ""
  },
  {
    "src": "/images/gallery/g-028.jpg",
    "alt": "",
    "title": "g-028",
    "caption": "",
    "description": ""
  },
  {
    "src": "/images/gallery/g-029.jpg",
    "alt": "",
    "title": "g-029",
    "caption": "",
    "description": ""
  },
  {
    "src": "/images/gallery/g-030.jpg",
    "alt": "",
    "title": "g-030",
    "caption": "",
    "description": ""
  }
]
```
