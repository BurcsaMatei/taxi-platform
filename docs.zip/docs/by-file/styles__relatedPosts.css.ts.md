# styles/relatedPosts.css.ts

**Ce face:** Fișier de cod parte din aplicație.

```ts
// styles/relatedPosts.css.ts
import { style } from "@vanilla-extract/css";

export const relatedWrapClass = style({
  maxWidth: 820,
  margin: "32px auto 64px",
});

export const relatedTitleClass = style({
  fontSize: 20,
  lineHeight: 1.2,
  marginBottom: 12,
});

export const relatedListClass = style({
  listStyle: "none",
  padding: 0,
  margin: 0,
  display: "grid",
  rowGap: 10,
});

export const relatedLinkClass = style({
  color: "#0ea5e9",
  textDecoration: "underline",
  selectors: {
    "&:hover": { textDecoration: "none" },
  },
});

```
