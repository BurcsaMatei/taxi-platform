# components/sections/contact/ShortTextContact.tsx

**Ce face:** Fișier de cod parte din aplicație.

```tsx
import { shortTextClass } from '../../../styles/shortText.css';

const ShortTextContact = () => (
  <h3 className={shortTextClass}>
    Suntem la un mesaj distanță — răspundem rapid și cu plăcere oricărei solicitări.
  </h3>
);

export default ShortTextContact;

```
