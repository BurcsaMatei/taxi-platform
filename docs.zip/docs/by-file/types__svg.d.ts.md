# types/svg.d.ts

**Ce face:** Fișier de cod parte din aplicație.

```ts
declare module "*.svg" {
  import * as React from "react";
  const SVG: React.FC<React.SVGProps<SVGSVGElement> & { title?: string }>;
  export default SVG;
}

```
