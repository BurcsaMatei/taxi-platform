# components/SkipLink.tsx

**Ce face:** Link accesibilitate: „sari la conținut”.

```tsx
import { skipLinkClass } from "../styles/skipLink.css";

export default function SkipLink() {
  return (
    <a href="#main-content" className={skipLinkClass}>
      Sari la conținutul principal
    </a>
  );
}

```
